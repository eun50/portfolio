// 기본 값 설정
function dw(s){
    document.write(s);
}
function br(){
    dw("<br>");
}

// 1. 클래스 선언
function Cat(name, age, kind){
    // 1-1. 클래스 - 맴버 변수
    this.name = name;
    this.age = age;
    this.kind = kind;

// 1-2. 클래스 내 함수 선언 = 멤버 함수//
this.introduce = function(){ // 선언 시에는 this. ~ 로 진행
    dw("고양이 이름 : " + this.name + "고양이 나이 : " + this.age + "고양이 종류 : " + this.kind);
    }
}

// 2. 클래스 객체 생성
var cat1 = new Cat();
cat1.name = "이름";
cat1.age = "나이";
cat1.kind = "종류";

var cat2 = new Cat();
cat2.name = "올리";
cat2.age = 1;
cat2.kind = "스코티시폴드";

var cats = [cat1, cat2];

for(var i=0; i<2; i++){
    cats[i].num=i+1;
}

cat1[0].introduce("고양이1");
br();
cat2[1].introduce("고양이2");
br();