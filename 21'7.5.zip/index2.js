// 기본 값 설정
function dw(s){
    document.write(s);
}
function br(){
    dw("<br>");
}


character[i].lv = r(3);

for(var i=0; i<10; i++){
    character[i].introcduce();
}